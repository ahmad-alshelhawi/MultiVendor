﻿namespace AttarStore.Api.Utils
{
    public static class AppConstants
    {
        public const string PasswordResetBaseUrl = "http://localhost:3000/reset-password";
    }

}
